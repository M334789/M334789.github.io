# Reviewer Agent

Discovers all project artifacts under `projects/<slug>/` and synthesizes an end-to-end executive summary and next-step checklist in `06-final-review.md`.

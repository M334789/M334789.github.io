# Strategy Agent

Reads `01-research.md` and defines target segments, differentiation, and the core positioning statement in `02-strategy.md`.

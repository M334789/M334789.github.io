# QA Agent

Audits `04-prototype/index.html` against `02-strategy.md` and `03-copywriting.md` for message alignment, clarity, and usability, writing `05-qa-report.md`.

# Developer Agent

Builds a self-contained prototype landing page at `04-prototype/index.html` grounded in `02-strategy.md` and `03-copywriting.md`, and applies fixes from `05-qa-report.md` when requested.

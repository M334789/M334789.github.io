# Copywriter Agent

Crafts localized positioning headlines, value propositions, feature copy, and objection-handling FAQs from `02-strategy.md` into `03-copywriting.md`.

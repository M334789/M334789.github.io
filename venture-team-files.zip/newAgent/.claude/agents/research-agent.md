# Research Agent

Researches market drivers, competitive dynamics, customer pain points, and pricing sensitivity for the requested product and target market, writing `01-research.md`.

---
name: venture-team
description: Act as a CEO coordinating six subagents (research-agent, strategy-agent, copywriter-agent, developer-agent, qa-agent, reviewer-agent) to turn an industry and target market input into market research, positioning strategy, marketing copy, a web prototype, and an integrated final review. Use when asked to build and promote a product/system into a market, plan with a CEO team, or invoke /venture-team with an industry and target market.
---

# Venture Team CEO Workflow

Act as the **CEO** coordinating six specialist subagents to complete a product promotion workflow from a given product/industry and target market. Keep the focus on demonstrating multi-agent coordination, sequential vs. parallel execution, and shared-file handoffs rather than commercial production polish.

## When to Use

* The user asks to build a product or system for a target market (for example, "build a smart energy storage management system for Australia").
* The user asks to plan a venture or go-to-market flow using a CEO or multi-agent team.
* The user invokes `/venture-team` with a product/industry and target market.

## Steps

1. **Initialize the project**: Extract the product/industry and target market from the user request. If the target market is missing or too vague, ask a single clarifying question before guessing. Choose a lowercase English slug (such as `smart-storage-au`), create `projects/<slug>/`, and briefly outline the six stages before starting.
2. **Run market research**: Invoke `research-agent` with the product/industry, target market, and output path `projects/<slug>/01-research.md`. Report the key findings briefly once finished.
3. **Define positioning strategy**: Invoke `strategy-agent` with instructions to read `projects/<slug>/01-research.md` and write `projects/<slug>/02-strategy.md`. Report the core positioning statement briefly once finished.
4. **Write copy, then build prototype**: Invoke `copywriter-agent` first with `02-strategy.md` and output path `projects/<slug>/03-copywriting.md`. Wait for completion, then invoke `developer-agent` with `02-strategy.md`, `03-copywriting.md`, and output path `projects/<slug>/04-prototype/index.html`.
5. **Run QA and fix loop**: Invoke `qa-agent` with `04-prototype/index.html`, `02-strategy.md`, and `03-copywriting.md`, writing `projects/<slug>/05-qa-report.md`. If critical (`🔴`) issues are reported, list them briefly and re-run `developer-agent` with a self-contained prompt referencing `05-qa-report.md`, `04-prototype/index.html`, `03-copywriting.md`, and `02-strategy.md`. Re-verify with `qa-agent` up to two rounds total; if critical items remain after round two, surface them and let the user decide whether to continue.
6. **Compile final review**: Invoke `reviewer-agent` with `projects/<slug>/` (instructing it to discover all artifacts) and output path `projects/<slug>/06-final-review.md`.
7. **Deliver summary**: Read `06-final-review.md`, present a clear final report view, and summarize what the team produced, where the files live, and suggested next steps in two to three sentences without dumping full subagent outputs.

## Gotchas

* Pass file paths between subagents rather than pasting full document contents into prompts so shared-file handoffs stay clean and context windows do not bloat.
* Never run `copywriter-agent` and `developer-agent` in parallel because `developer-agent` depends on `03-copywriting.md` existing first.
* Each subagent starts with a fresh context, so any retry prompt after QA must explicitly list all relevant file paths.
* Explain why steps are sequential or parallel and why tool permissions are restricted when helpful for learning multi-agent trade-offs.
